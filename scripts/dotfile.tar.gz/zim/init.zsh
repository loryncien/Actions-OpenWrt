zimfw() { source /root/.zim/zimfw.zsh "${@}" }
zmodule() { source /root/.zim/zimfw.zsh "${@}" }
fpath=(/root/.zim/modules/utility/functions /root/.zim/modules/zsh-completions/src ${fpath})
autoload -Uz -- mkcd mkpw
source /root/.zim/modules/environment/init.zsh
source /root/.zim/modules/termtitle/init.zsh
source /root/.zim/modules/utility/init.zsh
source /root/.zim/modules/asciiship/asciiship.zsh-theme
source /root/.zim/modules/completion/init.zsh
source /root/.zim/modules/fast-syntax-highlighting/fast-syntax-highlighting.plugin.zsh
source /root/.zim/modules/zsh-history-substring-search/zsh-history-substring-search.zsh
source /root/.zim/modules/zsh-autosuggestions/zsh-autosuggestions.zsh
source /root/.zim/modules/zsh-z/zsh-z.plugin.zsh
